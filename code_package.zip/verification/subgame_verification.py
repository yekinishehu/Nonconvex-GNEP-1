"""SymPy verification of every closed-form value in Sections 5 and 8.2 and
Appendix A of the manuscript.  Run:  python subgame_verification.py
"""
from sympy import Rational as R, symbols, solve, simplify, Abs

ok = 0
def check(name, expr, expected):
    global ok
    got = simplify(expr)
    assert got == expected, "%s: got %s, expected %s" % (name, got, expected)
    ok += 1
    print("PASS  %-46s = %s" % (name, expected))

x1, x2, x, lam = symbols('x1 x2 x lam')

# --- VE of the shared-capacity subgame (Thm: multipliers equal) ---
sol = solve([14 - x1 - 3 - lam, 14 - x2 - 4 - lam, x1 + x2 - 15], [x1, x2, lam])
check("VE flows (x1,x2)", (sol[x1], sol[x2]), (R(8), R(7)))
c = lambda a, xx: R(1,2)*xx**2 + a*xx
def tot(a1, a2, xx1, xx2, f=0):
    return c(a1, xx1) + c(a2, xx2) + f*(1 if xx1>0 else 0) + f*(1 if xx2>0 else 0)
def prof(a, xx):  return 14*xx - c(a, xx)

# --- Table 2: f = 0 ---
check("cent cost f=0", tot(3,4,8,7), R(217,2))        # 108.5
check("cent welfare f=0", 14*15 - tot(3,4,8,7), R(203,2))   # 101.5
check("dec cost f=0 (worst GNE)", tot(3,4,11,4), R(235,2))  # 117.5
check("dec welfare f=0", 14*15 - tot(3,4,11,4), R(185,2))   # 92.5
check("PoA f=0", simplify((14*15-tot(3,4,8,7))/(14*15-tot(3,4,11,4))), R(203,185))  # 1.097...
# --- f = 25 ---
check("cent cost f=25", tot(3,4,8,7,25), R(317,2))   # 158.5
check("dec cost f=25", tot(3,4,11,4,25), R(335,2))   # 167.5
check("PoA f=25", simplify((14*15-tot(3,4,8,7,25))/(14*15-tot(3,4,11,4,25))), R(103,85))
# --- f = 50: monopoly ---
check("monopoly cost f=50", c(3,11)+50, R(287,2))    # 143.5
check("monopoly welfare f=50", 14*11 - (c(3,11)+50), R(21,2))  # 10.5
check("W2 best-entry profit f=50", prof(4,4)-50, R(-18))       # priced out
# --- f = 75: no trade ---
check("solo welfare f=75 (W1)", simplify(max([14*t - c(3,t) - 75 for t in range(16)])), R(-29,2))
# --- GNE segment endpoints are mutual best responses ---
check("(11,4): W1 best resp.", 14-11-3 >= 0, True)   # wants more, capped
check("(11,4): W2 best resp.", 14-4-4, R(6))
check("(5,10): W1 marginal profit", 14-5-3, R(6))
# --- Prop. 5.4 numbers (c(x) = x^2/2, revenue 14x, f = 1) ---
check("pi1 all-active", 14*R(2,3) - (R(2,3)**2)/4 - 2, R(65,9))
check("pi2", 14*R(1,3) - R(1,2)*R(1,3)**2 - 1, R(65,18))
check("std dev profit", 14*R(2,3) - R(1,2)*R(2,3)**2 - 1, R(73,9))
check("hier dev profit", 14*R(1,2) - R(1,2)*R(1,2)**2 - 1, R(47,8))
check("std gain", R(73,9)-R(65,9), R(8,9))
check("hier loss", R(65,9)-R(47,8), R(97,72))
check("gap", R(73,9)-R(47,8), R(161,72))

# --- Appendix A: first-best tolls ---
xs = solve([14 - 2*x1 - x2 - 3, 14 - x1 - 2*x2 - 4], [x1, x2])
check("planner flows", (xs[x1], xs[x2]), (4, 3))
check("tau*", 14 - (xs[x1]+3), 7)
check("platform revenue", 7*4 + 7*3, 49)
check("H'(q*)q*", 7*7, 49)
check("platform profit k=0", 14*10 - R(1,10)*100, R(130))
check("platform profit k=1", 14*11 - R(1,10)*121 - 20, R(1219,10))

print("\nALL %d CHECKS PASSED" % ok)
